# Classic Game Brainstorm

These are original MGLabs-friendly concepts inspired by broad classic game genres and eras, not copies of copyrighted characters, maps, art, music, or branding.

## Kart Racing

- Pixel Kart Cup
- Turbo Toy Racers
- Neon Kart League
- Backyard Kart Bash
- Mall Kart Mayhem
- Space Kart Circuit
- Schoolyard Kart Rally
- Desert Buggy Cup
- Snow Kart Sprint
- City Rooftop Racers
- Arcade Kart Championship
- Micro Kart Garage
- Hover Kart Grand Prix
- Jungle Kart Rally
- Robot Kart League
- Night Drive Kart Cup
- Beach Buggy Bash
- Toybox Racers
- Retro Kart Tour
- Campus Kart Cup
- Cloud Kart Circuit
- Volcano Kart League
- Moon Kart Derby
- Underwater Kart Rush
- Cyber Kart Arena

## Arcade 80S 90S

- Vector Defender
- Neon Meteor
- Pixel Fortress
- Laser Paddle
- Galaxy Patrol
- Star Tunnel
- Robot Breakout
- Brick Reactor
- Alien Grid
- Astro Blaster
- Moon Lander Lab
- Orbit Patrol
- Neon Invaders
- Pixel Tank Arena
- Circuit Defender
- Arcade Reactor
- Cosmic Paddle
- Retro Defender
- Vector Runner
- Maze Chaser
- Ghost Grid
- Meteor Miner
- Space Rescue
- Arcade Pilot
- Laser Rally
- Pixel Hopper
- Rocket Dodge
- Turbo Tunnel
- Crystal Defender
- Arcade Storm

## Platformers

- Pixel Jump Quest
- Castle Climber
- Cave Runner
- Robot Platform Lab
- Sky Island Adventure
- Jungle Jump
- Moon Base Escape
- Clockwork Castle
- Cyber Platformer
- Volcano Vault
- Ice Tower
- Temple Climb
- Neon Rooftops
- Dungeon Jump
- Cloud Hopper
- Factory Escape
- Pixel Ninja Course
- Space Station Run
- Desert Ruins
- Water Temple
- Forest Tower
- Crystal Caverns
- Retro Hero
- Gravity Platformer
- Portal Tower
- Gearworks
- Skyline Sprint
- Lava Lab
- Robot Rescue
- Arcade Adventure

## Flash Web Era

- Desktop Tower Defense
- Ragdoll Puzzle Lab
- Stick Sprint
- Physics Cannon
- Launch Distance Challenge
- Bubble Pop Arena
- Clicker Factory
- Restaurant Rush
- Idle Arcade
- Mini Tycoon
- Parking Challenge
- Bike Stunt
- Desktop Pet
- Office Escape
- Browser Tower Defense
- Physics Stack
- Balloon Defense
- Mouse Accuracy Lab
- Typing Racer
- Reaction Test
- Paper Toss
- Helicopter Tunnel
- Line Rider Lab
- Doodle Jumper
- Browser Farm
- Pixel Shop Manager
- Cake Factory
- Airport Manager
- City Clicker
- Mini Golf Flashback

## Sports Old School

- Pixel Football Coach
- Retro Gridiron Manager
- Arcade Soccer Cup
- Penalty King
- Goalkeeper Hero
- Street Hoops 2D
- Free Throw Challenge
- Pixel Baseball Derby
- Home Run Arcade
- Retro Hockey
- Table Tennis Classic
- Arcade Bowling
- Mini Golf Classic
- Track & Field Sprint
- Skate Challenge
- Snowboard Slalom
- Bike BMX Trials
- Tennis Rally
- Volleyball Arcade
- Dodgeball Classic
- Pool Hall
- Air Hockey
- Foosball Lab
- Boxing Timing Game
- Wrestling Manager
- Golf Putting Lab
- Cricket Arcade
- Rugby Dash
- Soccer Manager
- Basketball Coach Simulator

## Racing Old School

- Top Down Racer
- Pseudo-3D Highway
- Outrun-style Neon Road
- Desert Rally
- Snow Rally
- City Night Racer
- Traffic Overtake
- Micro Machines-style Table Racer
- RC Car Cup
- Boat Sprint
- Bike Racer
- Formula Pixel
- Stock Car Arcade
- Drift Parking
- Mountain Pass Racer
- Police-free Chase Timer
- Airport Runway Racer
- Toy Car Bedroom Circuit
- Slot Car Simulator
- Hover Racer
- Future Bike Circuit
- Retro Rally Championship
- Truck Trial
- Bus Route Challenge
- Taxi Time Trial
- Road Trip Racer
- Hill Climb
- Motorcycle Sprint
- Kart Builder
- Track Editor Racer

## Puzzle Classics

- Block Drop
- Hex Drop
- Number Merge
- Color Lines
- Pipe Connect
- Push Box
- Sliding Tiles
- Memory Grid
- Sequence Lights
- Word Grid
- Logic Mines
- Marble Match
- Bubble Cluster
- Chain Reaction
- Tower Puzzle
- Switch Maze
- Laser Mirrors
- Circuit Puzzle
- Bridge Builder Puzzle
- Traffic Jam Puzzle
- Shape Sort
- Pattern Match
- Color Flood
- Tile Connect
- Letter Drop
- Math Blocks
- Gravity Puzzle
- Portal Puzzle
- Gear Puzzle
- Robot Logic

## Strategy Management

- Pixel City Mayor
- Theme Park Manager
- Mall Manager
- Airport Manager
- Game Studio Tycoon
- Computer Shop Tycoon
- Arcade Owner
- Football Club Manager
- Race Team Manager
- Space Colony Manager
- School Campus Manager
- Hospital Manager
- Restaurant Manager
- Hotel Manager
- Factory Manager
- Railroad Manager
- Shipping Port Manager
- Farm Manager
- Zoo Manager
- Movie Studio Manager
- Music Label Manager
- Tech Startup Manager
- Robot Factory
- Theme Arcade Manager
- Sports League Commissioner
- Retro Console Company
- Internet Cafe Manager
- Computer Lab Manager
- Festival Manager
- Stadium Manager

## Adventure Rpg

- BrowserQuest-style Adventure
- Pixel Dungeon
- Space Trader
- Island Explorer
- Mystery Mansion
- Detective Files
- Retro Fantasy Quest
- Robot RPG
- Cyber City Adventure
- Pirate Map Quest
- Temple Mystery
- Moon Colony Story
- Haunted Arcade
- Time Travel Quest
- School Mystery
- Museum Adventure
- Treasure Island
- Mountain Expedition
- Forest Guardian
- Desert Caravan
- Underwater Expedition
- Sky Kingdom
- Crystal Cave RPG
- Arcade Hero Quest
- Space Station Mystery
- Lost City
- Robot Rescue RPG
- Retro Detective
- Wizard School Adventure
- Pixel Frontier RPG