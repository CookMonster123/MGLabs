# MGLabs Complete GitHub Edition

This updated package expands the earlier GitHub build into a much broader public MGLabs archive and interface.

## Included
- 36 cataloged MGLabs apps/experiences
- Full searchable app catalog
- Category filter
- App version/tier index
- MGLabs build-history timeline
- Local browser recent-open tracking
- Launchpad
- BrightPath demo
- Device Lab simulated telemetry demo
- Arcade and Community areas
- Responsive design

## Production systems intentionally not copied
The live MGLabs project has additional backend/account/admin/support/analytics/game-publishing systems. Private production secrets, credentials, private user data, and hidden admin state are intentionally not included in this public package.

## Run
npm install
npm run dev

## Build
npm run build


## Idea Vault update

This version adds:
- 40 game concepts
- Future AI/learning ideas
- Coding/builder ideas
- Engineering/hardware ideas
- Community ideas
- Career/opportunity ideas
- Platform upgrade ideas
- A dedicated Ideas page
- A much larger Arcade concept library

The ideas are clearly treated as concepts/backlog items rather than falsely presented as already completed features.


## v5 Advanced update

This version adds:
- 12 deeper advanced game designs with systems/progression/AI/physics concepts
- 7 researched open-source browser-game/framework references
- Advanced roadmaps for major MGLabs apps
- New Inspiration page
- Expanded Arcade with Advanced vs Backlog modes
- More explicit architecture ideas for replayability, local saves, editors, telemetry, difficulty, AI opponents, physics and simulations

### Internet references
The external projects are **references**, not silently copied games. Before reusing code or assets from any external repository, check and follow its license.


## v6 Mega Games update

Added 20 more advanced original game concepts, including:

- Voxel Frontier — voxel crafting sandbox
- Metro Rush — three-lane endless runner
- Block Battle Arena — destructible voxel arena
- Street Dash X — parkour runner
- Skyline Skater — skating runner
- Roadstorm — traffic racing
- Island Builder — survival crafting
- Dungeon Blocks — voxel dungeon crawler
- Turbo Kart Lab — kart racing
- Rocket League Lab — vehicle soccer concept
- Castle Siege Builder — build-and-defend
- FarmCraft — farming/crafting
- Ocean Craft — raft survival
- City Driver — open-city driving
- Parkour Tower — obstacle-course platformer
- Battle Tiles — shrinking-arena strategy
- Creature Tamer Lab — original creature collection RPG
- Theme Park Builder — management simulation
- Mini Golf World — physics mini-golf
- Snowboard Rush — downhill arcade

These are original MGLabs concepts inspired by broad game genres. They are not copies of commercial games.


## v7 playable update

Added two actually playable original MGLabs games:

- **Metro Rush** — keyboard/touch three-lane endless runner with jumping, ducking, coins, increasing speed, obstacles and local best score.
- **Voxel Frontier: Build Mode** — lightweight block sandbox with placing, mining, a hotbar and inventory counts.

Also added third-party licensing research. A Subway Surfers WebGL repository was confirmed to have an MIT software license, but its bundled asset rights were not clear enough to safely redistribute. Eaglercraft forks carry a non-commercial license but are based on Minecraft, so Eaglercraft itself is not bundled.

This gives MGLabs the style of experiences requested while keeping the GitHub package safer to publish.


## v8 Public Games update

Added a **Public Games** section with 15 real open-source/public browser-game projects and libraries found online.

The biggest entries currently expose:
- 90s Games — 114 games
- Tiny Arcade — 257+ games
- Game-Zone — 20+ games

The catalog also includes real runner, racing, football/soccer, Breakout, platformer, RPG and 3D browser projects.

This version links to the real projects instead of pretending third-party games were created by MGLabs. Third-party files are not silently copied into this ZIP unless their complete code/asset licensing is verified.
