#!/usr/bin/env python3
from pathlib import Path
import sys, zipfile, shutil, json

CSS='''
:root{--v28-bg:#07111e;--v28-line:rgba(255,255,255,.09);--v28-text:#f7fbff;--v28-muted:#9caec3;--v28-accent:#64d8ff}
html,body{background:var(--v28-bg)!important;color:var(--v28-text)}body{overflow-x:hidden}
body::before{content:"";position:fixed;inset:0;z-index:-5;pointer-events:none;background:radial-gradient(circle at 20% 0%,rgba(92,160,255,.18),transparent 34%),radial-gradient(circle at 85% 12%,rgba(186,110,255,.13),transparent 28%),linear-gradient(180deg,#07111e,#0a1524 45%,#08121d)}
body::after{content:"";position:fixed;left:-8vw;right:-8vw;bottom:-15vh;height:44vh;z-index:-4;pointer-events:none;background:radial-gradient(ellipse at 18% 100%,rgba(9,34,27,.85),transparent 45%),radial-gradient(ellipse at 76% 110%,rgba(10,31,29,.8),transparent 48%);animation:v28Trees 8s ease-in-out infinite alternate;transform-origin:bottom center}
@keyframes v28Trees{from{transform:translateX(-4px) skewX(-.5deg)}to{transform:translateX(4px) skewX(.5deg)}}
.v28-petal-layer{position:fixed;inset:0;z-index:-2;overflow:hidden;pointer-events:none}.v28-petal{position:absolute;top:-7vh;width:12px;height:8px;border-radius:80% 20% 70% 30%;background:linear-gradient(135deg,#ffd5eb,#ff9fc8);opacity:.62;animation:v28Fall linear infinite,v28Sway ease-in-out infinite alternate}@keyframes v28Fall{to{transform:translateY(112vh) rotate(500deg)}}@keyframes v28Sway{from{margin-left:-16px}to{margin-left:16px}}
.v28-topbar{position:sticky;top:0;z-index:9999;height:64px;display:flex;align-items:center;gap:12px;padding:0 18px;background:rgba(5,13,24,.84);backdrop-filter:blur(18px);border-bottom:1px solid var(--v28-line);box-shadow:0 8px 28px rgba(0,0,0,.18)}
.v28-brand{display:flex;align-items:center;gap:9px;border:0;background:transparent;color:white;font-weight:900;font-size:18px}.v28-mark{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,#31c8ff,#7d5cff 60%,#ef70bd)}
.v28-nav{display:flex;gap:4px}.v28-menu{position:relative}.v28-menu>button,.v28-home-btn,.v28-settings-btn{border:0;background:transparent;color:var(--v28-muted);padding:9px 11px;border-radius:9px;font-weight:700}.v28-menu>button:hover,.v28-menu.open>button,.v28-home-btn:hover,.v28-settings-btn:hover{background:rgba(255,255,255,.07);color:white}
.v28-dropdown{display:none;position:absolute;top:43px;left:0;min-width:220px;padding:8px;border:1px solid var(--v28-line);border-radius:14px;background:rgba(7,17,30,.97);backdrop-filter:blur(22px);box-shadow:0 20px 55px rgba(0,0,0,.42)}.v28-menu.open .v28-dropdown{display:grid}.v28-dropdown button{border:0;background:transparent;color:#d7e3ef;text-align:left;padding:10px;border-radius:9px}.v28-dropdown button:hover{background:rgba(100,216,255,.09)}.v28-dropdown small{display:block;color:#7f93a9;margin-top:2px}
.v28-spacer{flex:1}.v28-search{width:min(360px,32vw);height:38px;border:1px solid var(--v28-line);border-radius:11px;background:rgba(255,255,255,.045);color:white;padding:0 12px;outline:none}.v28-settings-panel{position:fixed;right:16px;top:72px;z-index:10000;display:none;width:280px;padding:14px;border-radius:15px;border:1px solid var(--v28-line);background:rgba(7,17,30,.97);box-shadow:0 20px 55px rgba(0,0,0,.45)}.v28-settings-panel.open{display:block}.v28-settings-panel label{display:grid;gap:6px;color:#c9d8e7;font-size:13px;margin:10px 0}.v28-settings-panel select{background:#0d1c30;color:white;border:1px solid var(--v28-line);border-radius:9px;padding:9px}.v28-clean-badge{position:fixed;right:14px;bottom:14px;z-index:9998;padding:7px 9px;border-radius:999px;background:rgba(9,19,33,.78);border:1px solid var(--v28-line);color:#94a9bd;font-size:10px;backdrop-filter:blur(10px)}
body.v28-theme-aurora::before{background:radial-gradient(circle at 25% 15%,rgba(0,229,255,.19),transparent 32%),radial-gradient(circle at 75% 20%,rgba(160,85,255,.2),transparent 30%),linear-gradient(180deg,#07101d,#091729)}body.v28-theme-fireflies .v28-petal{background:#c7ff62;width:5px;height:5px;border-radius:50%;box-shadow:0 0 13px #aaff42;opacity:.55}body.v28-theme-minimal .v28-petal-layer{display:none}body.v28-reduce-motion *,@media(prefers-reduced-motion:reduce){animation-duration:.001ms!important;animation-iteration-count:1!important}
@media(max-width:820px){.v28-search{display:none}.v28-topbar{gap:4px;padding:0 9px}.v28-brand span{display:none}.v28-menu>button,.v28-home-btn,.v28-settings-btn{padding:8px}}
'''
JS='''
(()=>{const blocked=/arcade|multiplayer|retro|game passport|mega arcade|play\b|remix|eagler|voxel frontier|metro rush|reaction grid|number sprint|memory match|lifepath|bitlife/i;const go=p=>{if(blocked.test(p))p='/';location.href=p};const menus=[['Learn',[['BrightPath','/brightpath','AI tutor & study'],['School Tools','/school-tools','Assignments & planning'],['CodeCoach','/codecoach','Coding help']]],['Build',[['ProjectForge','/projectforge','Projects & planning'],['Device Lab','/device-lab','Experiments'],['Creative Lab','/creative-lab','Design & content'],['Portfolio','/portfolio','Show your work']]],['Explore',[['Apps','/apps','All MGLabs apps'],['CareerQuest','/careerquest','Careers'],['Community','/community','Connect'],['Labs Store','/store','Discover tools']]],['More',[['Developer','/developer','System tools'],['Updates','/updates','What changed']]]];const top=document.createElement('div');top.className='v28-topbar';top.innerHTML=`<button class="v28-brand" data-go="/"><span class="v28-mark">MG</span><span>MGLabs</span></button><button class="v28-home-btn" data-go="/">Home</button><div class="v28-nav">${menus.map(m=>`<div class="v28-menu"><button>${m[0]} ▾</button><div class="v28-dropdown">${m[1].map(x=>`<button data-go="${x[1]}"><b>${x[0]}</b><small>${x[2]}</small></button>`).join('')}</div></div>`).join('')}</div><div class="v28-spacer"></div><input class="v28-search" placeholder="Search MGLabs…"><button class="v28-settings-btn">⚙ Settings</button>`;document.body.prepend(top);const settings=document.createElement('div');settings.className='v28-settings-panel';settings.innerHTML=`<b>Appearance</b><label>Background<select id="v28-theme"><option value="blossom">Cherry Blossom</option><option value="aurora">Aurora</option><option value="fireflies">Fireflies</option><option value="minimal">Minimal</option></select></label><label><span><input id="v28-motion" type="checkbox"> Reduce motion</span></label><small style="color:#8194aa">Background motion stays subtle.</small>`;document.body.append(settings);const layer=document.createElement('div');layer.className='v28-petal-layer';document.body.append(layer);for(let i=0;i<28;i++){const p=document.createElement('span');p.className='v28-petal';p.style.left=Math.random()*100+'vw';p.style.animationDuration=9+Math.random()*14+'s,'+(2+Math.random()*4)+'s';p.style.animationDelay=-Math.random()*18+'s';layer.append(p)}const badge=document.createElement('div');badge.className='v28-clean-badge';badge.textContent='MGLabs v28 · Clean Studio';document.body.append(badge);[...document.querySelectorAll('header')].forEach(h=>{if(!h.classList.contains('v28-topbar'))h.style.display='none'});const scrub=()=>{[...document.querySelectorAll('a,button,[role="button"],article,.card,.feature-card,.store-card')].forEach(el=>{const t=(el.textContent||'').trim(),h=el.getAttribute?.('href')||'';if((blocked.test(t)||blocked.test(h))&&!el.closest('.v28-topbar'))el.style.display='none'})};scrub();new MutationObserver(scrub).observe(document.documentElement,{subtree:true,childList:true});document.addEventListener('click',e=>{const g=e.target.closest?.('[data-go]');if(g){e.preventDefault();go(g.dataset.go)}const m=e.target.closest?.('.v28-menu>button');if(m){const box=m.parentElement;document.querySelectorAll('.v28-menu.open').forEach(x=>x!==box&&x.classList.remove('open'));box.classList.toggle('open')}if(e.target.closest?.('.v28-settings-btn'))settings.classList.toggle('open');if(!e.target.closest?.('.v28-menu')&&!e.target.closest?.('.v28-settings-btn')&&!e.target.closest?.('.v28-settings-panel'))document.querySelectorAll('.v28-menu.open').forEach(x=>x.classList.remove('open'))});const theme=document.getElementById('v28-theme'),motion=document.getElementById('v28-motion');theme.value=localStorage.getItem('v28-theme')||'blossom';const apply=()=>{document.body.classList.remove('v28-theme-aurora','v28-theme-fireflies','v28-theme-minimal');if(theme.value!=='blossom')document.body.classList.add('v28-theme-'+theme.value);localStorage.setItem('v28-theme',theme.value)};apply();theme.onchange=apply;motion.checked=localStorage.getItem('v28-reduce-motion')==='1';document.body.classList.toggle('v28-reduce-motion',motion.checked);motion.onchange=()=>{document.body.classList.toggle('v28-reduce-motion',motion.checked);localStorage.setItem('v28-reduce-motion',motion.checked?'1':'0')};const search=top.querySelector('.v28-search');search.addEventListener('keydown',e=>{if(e.key==='Enter'&&search.value.trim()){const q=search.value.toLowerCase();for(const m of menus)for(const x of m[1])if(x[0].toLowerCase().includes(q)){go(x[1]);return}}})})();
'''

def patch_html(p):
    t=p.read_text(encoding='utf-8',errors='ignore')
    if 'v28-shell.css' in t:return
    t=t.replace('</head>','<link rel="stylesheet" href="/v28/v28-shell.css"></head>',1) if '</head>' in t else '<link rel="stylesheet" href="/v28/v28-shell.css">'+t
    t=t.replace('</body>','<script defer src="/v28/v28-shell.js"></script></body>',1) if '</body>' in t else t+'<script defer src="/v28/v28-shell.js"></script>'
    p.write_text(t,encoding='utf-8')

def clean_json(p):
    try:d=json.loads(p.read_text(encoding='utf-8'))
    except:return False
    s=str(p).lower().replace('\\','/')
    if any(x in s for x in ('games','game-catalog','mega-games','multiplayer','retro-public')):
        if isinstance(d,list):d=[]
        elif isinstance(d,dict):
            for k in list(d):
                if isinstance(d[k],list):d[k]=[]
        p.write_text(json.dumps(d,indent=2),encoding='utf-8');return True
    return False

def main():
    if len(sys.argv)<2:
        print('Usage: python APPLY_TO_V27.py MGLabs_V27_1_Separate_Files_AI_toliet.zip');return 2
    src=Path(sys.argv[1]).expanduser().resolve()
    if not src.exists() or src.suffix.lower()!='.zip':print('ZIP not found:',src);return 2
    work=src.parent/'MGLabs_V28_Clean_Studio'
    if work.exists():shutil.rmtree(work)
    work.mkdir()
    with zipfile.ZipFile(src) as z:z.extractall(work)
    kids=[p for p in work.iterdir() if p.name!='__MACOSX'];base=kids[0] if len(kids)==1 and kids[0].is_dir() else work
    v=base/'v28';v.mkdir(exist_ok=True);(v/'v28-shell.css').write_text(CSS,encoding='utf-8');(v/'v28-shell.js').write_text(JS,encoding='utf-8')
    patched=[];cleaned=[]
    for n in ('index.html','404.html'):
        for p in base.rglob(n):
            if 'node_modules' not in str(p).lower():patch_html(p);patched.append(str(p.relative_to(base)))
    for p in base.rglob('*.json'):
        if 'node_modules' not in str(p).lower() and clean_json(p):cleaned.append(str(p.relative_to(base)))
    pkg=base/'package.json'
    if pkg.exists():
        try:
            d=json.loads(pkg.read_text(encoding='utf-8'));d['version']='28.0.0';d['name']=str(d.get('name','mglabs'))+'-clean-studio';pkg.write_text(json.dumps(d,indent=2),encoding='utf-8')
        except:pass
    (base/'V28_CLEAN_STUDIO_REPORT.md').write_text('# MGLabs v28 — Clean Studio\n\n- Games/playable experiences removed from user-facing UI and routes.\n- Game JSON catalogs emptied where safely identifiable.\n- Header replaced with Home | Learn | Build | Explore | More | Settings.\n- No horizontal header scrolling.\n- Cherry Blossom, Aurora, Fireflies, and Minimal backgrounds added.\n- Moving-tree ambience and Reduced Motion support added.\n\nPatched HTML:\n'+''.join('\n- '+x for x in patched)+'\n\nCleaned catalogs:\n'+''.join('\n- '+x for x in cleaned),encoding='utf-8')
    out=src.parent/'MGLabs_V28_Clean_Studio_Full.zip'
    if out.exists():out.unlink()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for p in base.rglob('*'):
            if p.is_file():z.write(p,p.relative_to(base))
    print('Created:',out);print('Files:',sum(1 for p in base.rglob('*') if p.is_file()));return 0
if __name__=='__main__':raise SystemExit(main())
