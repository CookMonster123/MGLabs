MGLabs v28 — Clean Studio Transformer

This uses your COMPLETE v27.1 ZIP as the base, so the new version keeps the full project instead of shrinking it.

Changes applied:
- Removes/blocks every user-facing game and playable experience.
- Empties clearly identifiable game catalogs while avoiding broken source imports.
- Replaces the overcrowded scrolling header with:
  Home | Learn | Build | Explore | More | Settings
- Adds clean dropdown organization instead of putting every project in the header.
- Adds animated Cherry Blossom background with subtle moving-tree ambience.
- Adds Aurora, Fireflies, and Minimal themes.
- Adds Reduce Motion support.
- Creates MGLabs_V28_Clean_Studio_Full.zip and never changes the original v27.1 ZIP.

HOW TO USE
1. Put APPLY_TO_V27.py and MGLabs_V27_1_Separate_Files_AI_toliet.zip in the same folder.
2. Run:
   python APPLY_TO_V27.py MGLabs_V27_1_Separate_Files_AI_toliet.zip
3. Use the newly created MGLabs_V28_Clean_Studio_Full.zip.
